#
# ICEWS Phase II R Package Demo File
#
# note that the ``modelfitting'' demo is now just an alias for the ICEWS2 demo.

demo(ICEWS2)