# ICEWS Phase II R Package Demo File
#
# last updated 7/31/10

data(icews)
data(Wmatrices)

pauseforuser<-function() {
	cat("\nType Return to continue...\n")
	a<-readLines(n=1)
}


#
# A model of rebellion:
#
model.rebellion<-icewsest.lmer(rebellion~ recentonsets.rebellion + mil.conf.l3 + proximitytoelection + W.events.rebellion.l3 + (-1+ gdppc.l3|country), teststart="Jan09", header="Rebellion Model")

# insurgency:
model.insurgency<-icewsest.lmer(insurgency~ recentonsets.insurgency + lastelection + mil.conf.l3  + W.bl.std.crisisdomestic.l3 + USAconf.l3 + (-1  + gdppc.l3|country), teststart="Jan09", header="Insurgency Model") 


# crisisdomestic:
model.crisisdomestic<-icewsest.lmer(crisisdomestic~ recentonsets.crisisdomestic  + USAconf.l3 + gdpgrowth.l3 + W.bl.std.crisisdomestic.l3 + W.knn4.std.gdpgrowth.l3 + antiGovtviolence.l3 + anoc.l3  + (-1 + mil.conf.l3 + nextelection|country), teststart="Jan10", header="Domestic Crisis Model") # note the change in teststart here
#
# crisisintl:
model.crisisintl<-icewsest.lmer(crisisintl~recentonsets.crisisintl  + W.events.crisisintl.l3 + W.icews.crisisintl.l3 + mil.conf.l3 + ( USAconf.l3 |country), teststart="Jan09", header="International Crisis Model") # 

# violence:
model.violence<-icewsest.lmer(violence~  W.refugees.violence.l3 + nminorities.l3 + (1|country), teststart="Jan09", header="Ethnic Violence Model") 

