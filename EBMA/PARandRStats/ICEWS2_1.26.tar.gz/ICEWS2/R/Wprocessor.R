Wprocessor <-
function(W, Wvar, data, prefix, Wvarname){
	
	splag<-rep(NA,nrow(data))
	
	# first create the simultaneous lag
	monthlist<-unique(data$monthID)
	for (m in monthlist) splag[data$monthID==m] <- W[,,m] %*% Wvar[data$monthID==m]
	
	# now lag it by three months:
	splag.l3<-splag
	for (i in 4:length(monthlist)) splag.l3[data$monthID==monthlist[i]] <- splag[data$monthID==monthlist[i-3]]
	
	# make a name for the splag
	splagname<-paste(prefix, Wvarname, ".l3", sep="")
	# now prepare the output:
	output<-list(splag=splag, splagname=splagname)
	
	} # close Wprocessor function

