
# predict.lmer function

# testing stuff:

#model.crisisintl<-lmer(crisisintl~recentonsets.crisisintl  + USAcoop.l3 + W.events.crisisintl.l3 + W.icews.crisisintl.l3 + (-1 + nminorities.l3 + nextelection|country), data=subset(icews, as.numeric(icews$monthID)<145), family="binomial") 

#model<-model.crisisintl
#newdata<-icews

#a<-fitted(model.crisisintl)
#b<-predict.lmer(model.crisisintl, subset(icews, as.numeric(icews$monthID)<145))
#max(a-b) # should be trivial

predict.lmer<-function(model, newdata, link="logit"){
	
	indata<-model@frame
	
	# First calculate the fixed effects:
	
		# create a matrix, Xf, that just contains the data for the fixed effects:
		fevars<-names(fixef(model))
		
		Xf<-newdata[,fevars[fevars!="(Intercept)"]]
		
		# now add back a column of 1s if there was an intercept in the model formula:
		if (fevars[1]=="(Intercept)") Xf<-cbind(1, Xf)
	
		# ensure it's a matrix:
		Xf<-as.matrix(Xf)

		# Now calculate the fixed effects component, Yf:
		Yf<-Xf %*% fixef(model)
	
	# Now add the random effects:
	
		# create a matrix, Xr, that just contains the data for the random effects:
		revars<-names(ranef(model)[[1]])  # note that we need to use the [[1]] index here because ranef returns a list object whose first item contains the dataframe of random effects
		
		Xr<-newdata[,revars[revars!="(Intercept)"]]

		# now add back a column of 1s if there was an intercept in the model formula:
		if (revars[1]=="(Intercept)") Xr<-cbind(1, Xr)
	
		# ensure it's a matrix:
		Xr<-as.matrix(Xr)
		
		# find the column in newdata that contains the grouping factor:
		gfname<-names(ranef(model))
		gf<-newdata[,gfname]
		
		# create a placeholder vector for the random effects component, Yr:
		Yr<-rep(NA, nrow(newdata))
		
		# Now loop through the factors in the newdata, calculating the random effects for each group:
		for (f in unique(gf)){
			randomeffects.current<-t(as.matrix(ranef(model)[[1]][rownames(ranef(model)[[1]])==f,]))
			
			Yr[gf==f]<- Xr[gf==f,] %*% randomeffects.current
			
			} # close f loop
	
	# Now add the fixed effects and random effects:
	linearpredictor<-Yf+Yr
	linearpredictor<-as.vector(linearpredictor)
	
	# Now do the logit transformation
	if (link=="logit") Yhat<-plogis(linearpredictor)
	if (link=="linear") Yhat<-linearpredictor
	
	invisible(Yhat)
	
	} # close predict.lmer function
	
