
whatif<-function(icewsobject, country, year, month, variabletochange, newvalue, data=icews){

	# first call the drilldown function without producing the graphics:
	A<-drilldown(icewsobject, country, year, month, data, resultstable=F, arrowdiagram=F, separationplot=F)
	
	calc<-rbind(A$fixed, A$random)
	colnames(calc)<-c("B", "Xi", "XBi")
	
	varnames<-rownames(calc)
	
	if (!(variabletochange %in% varnames)) stop("Can't find a variable with the name '",variabletochange ,"' in this model.  Your available choices are: '", paste(varnames, collapse="', '"), "'")
	
	calc.new<-calc
	calc.new[variabletochange, "Xi"]<-newvalue
	calc.new[,"XBi"]<-calc.new[,"B"]*calc.new[,"Xi"]
	
	phat.old<-plogis(sum(calc[,"XBi"]))
	phat.new<-plogis(sum(calc.new[,"XBi"]))
	
	oldvalue<-unique(calc[variabletochange, "Xi"])
	
	
	# report the results:
	
	if (phat.new>phat.old)  cat("Changing the value of ", variabletochange, " from its actual value of ", round(oldvalue,3) , " to a new value of ", round(newvalue, 3), " results in an increase in the probability of ", A$modelname, " for ", country, " in ", c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")[month], " ", year, " from ", signif(phat.old, 3), " to ", signif(phat.new,3) , ".", sep="" )

	if (phat.new<phat.old)  cat("Changing the value of ", variabletochange, " from its actual value of ", round(oldvalue,3) , " to a new value of ", round(newvalue, 3), " results in a decrease in the probability of ", A$modelname, " for ", country, " in ", c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")[month], " ", year, " from ", signif(phat.old, 3), " to ", signif(phat.new,3) , ".", sep="" )

	if (phat.new==phat.old)  cat("Changing the value of ", variabletochange, " from its actual value of ", round(oldvalue,3) , " to a new value of ", round(newvalue, 3), " has no effect on the probability of ", A$modelname, " for ", country, " in ", c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")[month], " ", year, ".", sep="" )
	
	# store the output
	invisible(list(phat.old=phat.old, phat.new=phat.new))
	
	} # close whatif function