separationplot.icews <-
function(pred, actual, line=T, lwd1=0.5, lwd2=0.5, heading, xlab="", shuffle=T, width=9, height=1.2, type="line", flag=NULL, flagcol=1, file=NULL, newplot=T, locate=NULL, rectborder=NULL){

	# redefine the quartz function if the user is on a Windows platform:
	if (.Platform[[1]]=="windows") quartz<-function(...) windows(...)
	
	# do some error-testing first:
	if (is.vector(pred)==F) stop("The pred argument needs to be a vector")
	if (is.vector(actual)==F) stop("The actual argument needs to be a vector")
	if (length(pred)!=length(actual)) stop("The pred and actual vectors are of different lengths.")
	if (any(is.na(pred))) stop("Missing values in the pred vector.")
	if (any(is.na(actual))) stop("Missing values in the actual vector.")
	
	resultsmatrix<-data.frame(pred, actual, flags=0)
	rows<-nrow(resultsmatrix)
	
	if (!is.null(flag)) resultsmatrix$flags[flag]<-1
	
	if (shuffle==T){
	set.seed(1)
	resultsmatrix<-resultsmatrix[sample(1:rows,rows),]
		} # close if shuffle==T condition
	
	# sort the results matrix
	resultsmatrix<-resultsmatrix[order(resultsmatrix$pred),]
	resultsmatrix<-cbind(resultsmatrix, position=1:rows)
	
	# warn user if there are relatively few discrete values of pred:
	if (shuffle==F & length(unique(pred))<0.9*length(pred)) warning("Your pred vector contains one or more long runs of identical values.  The separation plot needs to be interpreted with care.  Alternatively, try setting shuffle=T.")
	
	# open the plot space only if newplot==T:
	if (newplot==T){
		if (is.null(file)) quartz(width=width, height=height)
		if (!is.null(file)) pdf(file=file, width=width, height=height)
		par(mgp=c(3,0,0), lend=2, mar=c(2,2,2,2))	
		} # close newplot==T condition
	
	plot(1:nrow(resultsmatrix),1:nrow(resultsmatrix), xlim=c(0.5, nrow(resultsmatrix)+0.5), ylim=c(0,1),  type="n", bty="n", yaxt="n", xaxt="n", xlab=xlab, ylab="")
	cex<-1
	if (nchar(heading)>50) cex<-0.9
	if (nchar(heading)>70) cex<-0.8
	if (nchar(heading)>100) cex<-0.7
	title(main=heading, cex.main=cex)
	
	events<-resultsmatrix[resultsmatrix$actual==1,]
	nonevents<-resultsmatrix[resultsmatrix$actual==0,]
	
	# add the line segments
	if (type=="line"){
		if (nrow(nonevents)>0) segments(x0=nonevents$position, x1=nonevents$position, y0=0, y1=1, col="#FEF0D9", lwd=lwd1)
		if (nrow(events)>0) segments(x0=events$position, x1=events$position, y0=0, y1=1, col="#E34A33", lwd=lwd1)
		# add flags:
		if (!is.null(flag)) segments(x0=resultsmatrix$position[resultsmatrix$flags==1], x1=resultsmatrix$position[resultsmatrix$flags==1], y0=0, y1=1, col=flagcol, lwd=lwd1)
		}
	
	# add rectangles:
	if (type=="rect"){
		if (nrow(nonevents)>0) rect(xleft=nonevents$position-0.5, ybottom=0, xright=nonevents$position+0.5, ytop=1, col="#FEF0D9", border=rectborder)
		if (nrow(events)>0) rect(xleft=events$position-0.5, ybottom=0, xright=events$position+0.5, ytop=1, col="#E34A33", border=rectborder)
		# add flags:
		if (!is.null(flag)) rect(xleft=resultsmatrix$position[resultsmatrix$flags==1]-0.5, xright=resultsmatrix$position[resultsmatrix$flags==1]+0.5, ybottom=0, ytop=1, col=flagcol,  border=rectborder)
		}
	
	# add a line showing the predicted probabilities
	if (line==T)
	lines(1:rows, resultsmatrix$pred, lwd=lwd2)
	
	# close pdf device:
	if (!is.null(file)) dev.off()
	
	# locate the points:
	if (!is.null(locate)) {
		a<-locator(n=locate)
		resultsmatrix[round(a$x),]
		} # close locate condition
	
	} # close separationplot.icews function

