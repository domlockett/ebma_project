
# Code to generate predictions for a given observation based on the model object:

# arguments:
# icewsobject: output of icewsest.lmer
# country: character string representing the country to choose
# year: year (as a number)
# month: month (as a number from 1-12)
# arrowdiagram: should the arrow diagram be plotted?
# xmargin: amount of extra margin to the left and right of the arrow diagram, to allow for clearer display of the variable names.  This is in units of eta (the x-axis).
# cex: Character expansion factor to use in the arrowdiagram
# separationplot: should the separation plot be plotted?

# testing stuff:
# icewsobject=model.rebellion; country="India"; year=2010; month=1; data=icews; resultstable=T; arrowdiagram=T; xmargin=4; cex=0.8; separationplot=T

drilldown<-function(icewsobject, country, year, month, data=icews, resultstable=T, arrowdiagram=T, xmargin=4, cex=0.8, separationplot=T){
		
	model<-icewsobject$model
	
	if (class(model)!="mer") stop("This function only works for model objects estimated with the lmer function.")

	# redefine the quartz function if the user is on a Windows platform:
	if (.Platform[[1]]=="windows") quartz<-function(...) windows(...)

	# Express the DVname in a clearer format:	
	a<-c("rebellion", "insurgency", "crisisdomestic", "crisisintl", "violence")
	b<-c("Rebellion", "Insurgency", "Domestic Crisis", "International Crisis", "Ethnic Violence")
	modelname<-b[icewsobject$DVname==a]
	
	# identify the row in the icews dataframe corresponding to the required country-month observation:
	rowref<-data$country==country & data$year==year & data$month==month
	if (sum(rowref)!=1) stop("Can't find a unique match for the requested country-month in the supplied data set.")
	
	actual<-data[rowref,icewsobject$DVname]
	
	# get the coefficients of the fixed effects:
	Bf<-fixef(model)
	fenames<-names(Bf)
	
	# find the covariate values for the fixed effects:
	Xf<-rep(NA, length(Bf))
	for (i in 1:length(Xf)){
		if (fenames[i]=="(Intercept)") Xf[i]<-1 else Xf[i]<-data[rowref, fenames[i]]
		
		} # close i loop
	
	# get the coefficient(s) for the random effects:
	BR<-ranef(model)[[1]]
	renames<-names(BR)
	
	# get the grouping factor:
	gf<-names(ranef(model))
	f<-data[rowref,gf]
	
	# now get the coefficients of the random effects for the current factor:
	Br<-as.vector(as.matrix(BR[f,]))

	# find the covariate values for the random effects:
	Xr<-rep(NA, length(Br))
	for (i in 1:length(Xr)){
		if (renames[i]=="(Intercept)") Xr[i]<-1 else Xr[i]<-data[rowref, renames[i]]
		
		} # close i loop
	
	# Now print the output
	Outf<-cbind(Bf, Xf, Bf*Xf)	
	Outr<-cbind(Br, Xr, Br*Xr)
	rownames(Outr)<-renames
	colnames(Outf)[3]<-"XB"
	colnames(Outr)[3]<-"XB"
	
	eta<-sum(Outf[,3])+sum(Outr[,3])
	
	spacer1<-matrix("", nrow=1, ncol=3, dimnames=list(c( "Fixed Effects:")))
	spacer2<-matrix("", nrow=3, ncol=3, dimnames=list(c("subtotal:", "", "Random Effects:")))
	spacer2[1,3]<-round(sum(Outf[,3]),3)
	spacer3<-matrix("", nrow=3, ncol=3, dimnames=list(c("subtotal:", "", "Total:")))
	spacer3[1,3]<-round(sum(Outr[,3]),3)
	spacer3[3,3]<-round(round(sum(Outf[,3]),3)+round(sum(Outr[,3]),3),3)
	
	output<-rbind(spacer1, round(Outf,3), spacer2, round(Outr,3), spacer3)
	colnames(output)<-c("Beta_i", "X_i", "eta_i")
	
	monthlist<-c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
	
	if (resultstable==T) {
	
		cat("For ", country, " in ",monthlist[month], " of ", year, ", the probability of ",modelname, " estimated by this model is ", round(plogis(eta),3), ".  (The actual value of ", modelname, " for that month was ", actual ,".)  The corresponding value of the linear predictor (eta) is ", round(eta, 3), ", which in turn is made up of the following components:\n\n", sep="")
		
		print(output, quote=F)	
			
		} # close resultstable routine
	
	
	### arrowdiagram routine
	if (arrowdiagram==T){
		
		quartz(width=6, height=6)
		par(mfrow=c(2,1))
		par(mar=c(4, 4, 3, 2) + 0.1)
		par(cex=cex)
		
		red<-"#ca0020"; blue<-"#0571b0"; green<-"#4daf4a"
		colorscheme<-c(red, blue)
		names(colorscheme)<-c("right","left")
		justify<-c(1,0)
		names(justify)<-c("right", "left")
		
		# calculate the range of the x-axis:
		etas<-c(Outf[,3], Outr[,3])
		xmin<-min(cumsum(etas))-xmargin
		xmax<-max(cumsum(etas))+xmargin
		if (xmin>0) xmin<-0 # make sure that it always includes zero
		if (xmax<0) xmax<-0
		textpos<-c(xmin, xmax)
		names(textpos)<-c("right", "left")
		
		phat<-plogis(eta)
				
		# upper plot:
		plot(1:10,1:10, type="n", xlim=c(xmin, xmax), ylim=c(-0.1,1.1), bty="n", xlab=expression(hat(eta)), ylab="", las=1 )
		title(main=bquote(.(paste(modelname, " Model: ", country, ", ", monthlist[month]," ", year, " ", sep="")) (hat(p) == .(round(phat, 2)))))
		mtext(expression(hat(p)), 2.5, las=1, line=3, cex=cex)
		etaline<-seq(from=xmin, to=xmax, length.out=100)
		lines(etaline, plogis(etaline))
		arrows(x0=eta, x1=eta, y0=-1, y1=phat, col=green, length=0.1)
		arrows(x1=xmin, x0=eta, y0=phat, y1=phat, col=green, length=0.1)
		text(eta+0.4, 0.5*phat, bquote(hat(eta) == .(round(eta, 2)))  , adj=c(0,0), srt=45)
		phatposition<-phat
		if (phatposition>0.8) phatposition<-phat-0.4
		text(mean(c(xmin, eta)), phatposition+0.05, bquote(hat(p) == .(round(phat, 2))), adj=c(0, 0), srt=45)
		
		# lower plot:
		par(mar=c(4, 4, 2, 2) + 0.1)
		if (length(etas)<=10) ylim<-c(1,10) else ylim<-c(1,length(etas)+2)
		plot(1:10,1:10, type="n", xlim=c(xmin, xmax), bty="n", xlab=expression(hat(eta)), ylab="", yaxt="n", ylim=ylim)
		
		varnames<-c(paste(rownames(Outf), "(F)"), paste(rownames(Outr), "(R)"))
		
		# now go through all the terms, plotting the arrows:
		x0<-0
		for (i in 1:length(etas)){
			x1<-x0+etas[i]
			# find out if the arrow is pointing right or left:
			if (x1>x0) direction<-"right" else direction<-"left"
			if (x1>x0) pointcol<-red else pointcol<-blue
			if (abs(x0-x1)>0.01) arrows(x0=x0, y0=i, x1=x1, y1=i, length=0.1, lwd=3, col=colorscheme[direction], lend=1) else points(x0, i, col=pointcol, pch=19)
			
			# text(x0, i, varnames[i], adj=justify[direction])
			text(textpos[direction], i, varnames[i], adj=as.numeric(!as.logical(justify[direction])), col=colorscheme[direction])
			
			x0<-x1

			} # close i loop
		
		text(xmin, i+2, "Aggravating Factors:", adj=0)
		text(xmax, i+2, "Mitigating Factors:", adj=1)
		#abline(v=eta, col=green)
		arrows(x0=eta, x1=eta, y0=0, y1=10, col=green, length=0.1)
		
		} # close arrowdiagram routine
	
	
	### separation plot routine
	if (separationplot==T){
		
		# establish whether the country-month is in the training set or the test set:
		monthID<-paste(c("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[month], substr(year,3,4), sep="")
		
		intraining<-monthID %in% icewsobject$trainingset$monthID
		
		# now find the row number for the observation to flag:
		if (intraining==T) rownumber<-which(icewsobject$trainingset$monthID==monthID & icewsobject$trainingset$country==country) else rownumber<-which(icewsobject$testset$monthID==monthID & icewsobject$testset$country==country)
		
		
		# Now do the separation plots:
		quartz(height=3, width=9)
		par(mgp=c(3,0,0), lend=2, mar=c(2,2,2,2), mfrow=c(2,1))
		
		if (intraining==T) separationplot.icews(pred=icewsobject$in.pred, actual=icewsobject$trainingset[,icewsobject$DVname], newplot=F, heading=paste(modelname, " Model, In-Sample (", country, " in ", monthlist[month], " ", year, " is shown in blue).", sep=""), flag=rownumber, flagcol=blue) else separationplot.icews(pred=icewsobject$in.pred, actual=icewsobject$trainingset[,icewsobject$DVname], newplot=F, heading=paste(modelname, "Model, In-Sample"))
		
		if (nrow(icewsobject$testset)<100) plottype<-"rect" else plottype<-"line"
		
		if (intraining==F) separationplot.icews(pred=icewsobject$out.pred, actual=icewsobject$testset[,icewsobject$DVname], newplot=F, lwd1=1, heading=paste(modelname, " Model, Out-of-Sample (", country, " in ", monthlist[month], " ", year, " is shown in blue).", sep=""), type=plottype, flag=rownumber, flagcol=blue) else separationplot.icews(pred=icewsobject$out.pred, actual=icewsobject$testset[,icewsobject$DVname], newplot=F, lwd1=1, heading=paste(modelname, "Model, Out-of-Sample"), type=plottype)
		
		
		} # close separationplot==T routine
	
	
	# return the output:
	invisible(list(fixed=Outf, random=Outr, modelname=modelname))
	
	
	} # close drilldown function
	
