basicest <-
function(formula, data=icews, file=NULL, header=NULL, teststart="Jan08", ...){
	
	# extract the DV and IVs from the model formula
	a<-as.character(formula)
	lhs<-a[2]
	rhs<-strsplit(a[3], split=" + ", fixed=T)[[1]]
	Y<-data[lhs]
	X<-data[rhs]
	
	# create the training and test sets:
	IDs<-data[,c("country", "iso", "year", "month", "monthID")]
	
	# translate the teststart field into an appropriate month and year:
	teststart<-which(levels(data$monthID)==teststart)
	
	trainingset<-cbind(IDs,Y,X)[as.numeric(data$monthID)<teststart,]	
	testset<-cbind(IDs,Y,X)[as.numeric(data$monthID)>=teststart,]
	
	# estimate the model using the pre-2008 data only:
	model1 <- glm(formula, data=trainingset, family="binomial")
	print(summary(model1))
	
	# get the out-of-sample predictions:
	oospred<-predict.glm(model1, newdata=testset, type="response")
	
	if (is.null(file)) quartz(height=3, width=9) else pdf(file=file, height=3, width=9)
	if (is.null(header)) header<-paste(lhs, "~", paste(rhs, collapse="+"), sep="")
	par(mgp=c(3,0,0), lend=2, mar=c(2,2,2,2), mfrow=c(2,1))
	
	# Now make the separationplot for the in-sample and out-of-sample predictions:
	
	separationplot.icews(pred=model1$fitted.values, actual=trainingset[,lhs], newplot=F, heading=paste("In-Sample:", header ), ...)
	
	if (nrow(testset)<100) plottype<-"rect" else plottype<-"line"
	separationplot.icews(pred=oospred, actual=testset[,lhs], newplot=F, lwd1=1, heading=paste("Out-of-Sample: ", header), type=plottype, ...)
	
	if (!is.null(file)) dev.off()

	invisible(list(in.pred=model1$fitted.values, out.pred=oospred, trainingset=trainingset, testset=testset, model=model1))
	
	} # close basicest function

