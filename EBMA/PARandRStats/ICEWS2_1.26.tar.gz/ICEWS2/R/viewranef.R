
# function to visualize random effects
viewranef<-function(icewsobject){
	
	model<-icewsobject$model
	
	if (class(model)!="mer") stop("This function only works for model objects estimated with the lmer function.")
	
	# redefine the quartz function if the user is on a Windows platform:
	if (.Platform[[1]]=="windows") quartz<-function(...) windows(...)

	# Express the DVname in a clearer format:	
	oldname<-c("rebellion", "insurgency", "crisisdomestic", "crisisintl", "violence")
	newname<-c("Rebellion", "Insurgency", "Domestic Crisis", "International Crisis", "Ethnic Violence")
	modelname<-newname[icewsobject$DVname==oldname]
	
	red<-"#ca0020"; blue<-"#0571b0"; green<-"#4daf4a"

	a<-ranef(model)[[1]]
	
	quartz(width=3*ncol(a), height=6)
	par(mfrow=c(1, ncol(a)))
	par(cex=0.7)
	
	for (j in 1:ncol(a)){

		plot(1,1, type="n", ylim=range(a[,j]), main=paste(modelname, "Model:" ,colnames(a)[j]), bty="n", las=1, xaxt="n", xlab="", ylab=expression(hat(beta)))
		colorscheme<-rep(NA, nrow(a))
		colorscheme[a[,j]>=0]<-red
		colorscheme[a[,j]<0]<-blue
		abline(h=0, col=green)
		text(1, a[,j], rownames(a), col=colorscheme)
		
		}# close j loop
	
	} # close viewranef function