icewsest <-
function(formula, data=icews, W1=NULL, Wvar1=NULL, W2=NULL, Wvar2=NULL, ...){
	
	newdata<-data
	newformula<-formula
	
	# check to see if the user added a spatial lag in the first place:
	if (!is.null(W1) & !is.null(Wvar1)){
		
		# get the names of the variables:
		Wvar1name<-as.character(substitute(Wvar1))
		W1name<-as.character(substitute(W1))
		if (length(W1name)==3) W1name<-W1name[3] # fix the problem with the $ sign
		if (length(Wvar1name)==3) Wvar1name<-Wvar1name[3] # fix the problem with the $ sign
	
		output1<-Wprocessor(W=W1, Wvar=Wvar1, data, prefix=paste(W1name,".", sep=""), Wvarname=Wvar1name) # get the spatially-lagged variable
		
		# now append the spatially lagged variable to the data frame:
		newdata<-cbind(newdata,output1$splag)
		names(newdata)[ncol(newdata)]<-output1$splagname
		
		# now add the lagged variable to the model formula:
		a<-as.character(newformula)
		newformula<-as.formula(paste(a[2], "~", a[3], "+", output1$splagname))
		
		} # close W1 condition
		
	
	# now check to see if the user requested a second spatial lag:
	if (!is.null(W2) & !is.null(Wvar2)){
		
		Wvar2name<-as.character(substitute(Wvar2))
		W2name<-as.character(substitute(W2))
		if (length(W2name)==3) W2name<-W2name[3]
		if (length(Wvar2name)==3) Wvar2name<-Wvar2name[3] # fix the problem with the $ sign


		output2<-Wprocessor(W=W2, Wvar=Wvar2, data, prefix=paste(W2name,".", sep=""), Wvarname=Wvar2name) # get the spatially-lagged variable
		newdata<-cbind(newdata,output2$splag)
		names(newdata)[ncol(newdata)]<-output2$splagname
		a<-as.character(newformula)
		newformula<-as.formula(paste(a[2], "~", a[3], "+", output2$splagname))
		} # close if W2 condition
	
	# run icewsest using the new formula and new dataframe:
	output<-basicest(newformula, data=newdata, ...)
	invisible(output)
	
	} # close icewsest function

