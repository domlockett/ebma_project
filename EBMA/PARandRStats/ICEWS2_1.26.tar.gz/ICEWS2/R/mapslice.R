
# mapslice function

mapslice<-function(icewsobject, year, month, type="actuals", file=NULL, map=icewsmap, data=icews){
	
	require(maptools)
	
	# redefine the quartz function if the user is on a Windows platform:
	if (.Platform[[1]]=="windows") quartz<-function(...) windows(...)

	monthname<-c("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")[month]
	
	# Express the DVname in a clearer format:	
	oldname<-c("rebellion", "insurgency", "crisisdomestic", "crisisintl", "violence")
	newname<-c("Rebellion", "Insurgency", "Domestic Crisis", "International Crisis", "Ethnic Violence")
	modelname<-newname[icewsobject$DVname==oldname]
	
	
	if (is.null(file)) quartz() else pdf(file=file)
	
	if (type=="actuals"){
		colordata<-data[data$year==year & data$month==month,icewsobject$DVname]
		colorscheme<-rep(NA, 29)
		colorscheme[colordata==1]<-"#e31a1c"
		colorscheme[colordata==0]<-"#4daf4a"
		
		plot(map, col=colorscheme)
	
		text(100, 90, paste("Instances of ", modelname, ": ", monthname, " ", year, sep=""))
	
		# add the legend:
		rect(xleft=20, xright=25, ybottom=c(0,5), ytop=c(5,10), border=NA, col=c("#e31a1c", "#4daf4a"))
		text(28, c(0,5), c(modelname, paste("No", modelname)), adj=c(0,0), cex=0.8)
		text(20, 12, "Key:", cex=0.8, adj=c(0,0))
		
		} # close type==actuals condition
	
	
	if (type=="predictions"){
		
		fulldata<-cbind(rbind(icewsobject$trainingset, icewsobject$testset), c(icewsobject$in.pred, icewsobject$out.pred))
		names(fulldata)[ncol(fulldata)]<-"pred"
		
		pred.current<-fulldata[fulldata$year==year & fulldata$month==month, "pred"]
		
		colorscheme<-rgb(red=1, blue=1-pred.current, green=1-pred.current)
		
		plot(map, col=colorscheme)
	
		text(100, 90, paste("Predictions for ", modelname, ": ", monthname, " ", year, sep=""))
		
		# add the legend:
		rect(xleft=seq(51, 150, length.out=100), xright=seq(51, 150, length.out=100)+1, ybottom=-55, ytop=-50, border=NA, col=rgb(1, 1-seq(0,1, length.out=100), 1-seq(0,1, length.out=100)))
		text(100, -48, paste("Probability of", modelname), cex=0.8)
		text(seq(50, 150, length.out=11), -58, seq(0,1,0.1), cex=0.6)
		
		} # close type==predictions
	
	if (!is.null(file)) dev.off()
	
	} # close mapslice function