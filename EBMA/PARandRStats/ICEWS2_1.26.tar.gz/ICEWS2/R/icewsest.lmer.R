
# icewsest.lmer
#
# Function to estimate mixed effects models with the icews data.
#
# Brian Greenhill, May 17, 2010.

# Notes:
# note that this does not allow for the simultaneous calculation of the spatial lags.  They will need to have been already included in the icews dataframe.


icewsest.lmer<-function(formula, data=icews, file=NULL, header=NULL, teststart="Jan08", ...){

	
	# extract the DV from the model formula
	a<-as.character(formula)
	lhs<-a[2]
	
	
	# create the training set and test set:
		# translate the teststart field into an appropriate month and year:
		teststart<-which(levels(data$monthID)==teststart)
		
		trainingset<-data[as.numeric(data$monthID)<teststart,]	
		testset<-data[as.numeric(data$monthID)>=teststart,]
	
	# estimate the model using the training set:
	model<-lmer(formula, data=trainingset, family="binomial")
	
	# get the in-sample predictions:
	in.pred<-fitted(model)
	
	# make out-of-sample predictions using the test set (using my predict.lmer function):
	out.pred<-predict.lmer(model, newdata=testset)
	
	# Now do the separation plots:
		if (is.null(file)) quartz(height=3, width=9) else pdf(file=file, height=3, width=9)
		if (is.null(header)) header<-paste(a[2], "~", a[3], collapse=" ")
		par(mgp=c(3,0,0), lend=2, mar=c(2,2,2,2), mfrow=c(2,1))
		
		separationplot.icews(pred=in.pred, actual=trainingset[,lhs], newplot=F, heading=paste("In-Sample:", header ), ...)
		
		if (nrow(testset)<100) plottype<-"rect" else plottype<-"line"
		
		separationplot.icews(pred=out.pred, actual=testset[,lhs], newplot=F, lwd1=1, heading=paste("Out-of-Sample: ", header), type=plottype, ...)
		
		if (!is.null(file)) dev.off()
	
	# calculate the AUC scores:
	in.auc<-somers2(in.pred, trainingset[,lhs])[1]
	out.auc<-somers2(out.pred, testset[,lhs])[1]
	
	# return the output
	invisible(list(model=model, trainingset=trainingset, testset=testset, in.pred=in.pred, out.pred=out.pred, in.auc=in.auc, out.auc=out.auc, DVname=lhs))
	
	} # close icewsest.lmer function


