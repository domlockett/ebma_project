# ppBMA demo file
#
# last updated 12/14/10

data(example)

my.models<-data.frame(example$Duke, example$SAE)
names(my.models)<-c("Duke", "SAE")

my.controls<-data.frame(example$country, example$year, example$month)
names(my.controls)<-c("Country", "Year", "Month")

fit1<-pred.prob.BMA(y=example$y, x=my.models, training=example$training, control=my.controls)

dev.new(width=7, height=5)
par(mfrow=c(1,2), ask=FALSE)
plot.ppBMA(fit1, type="All")
plot.ppBMA(fit1, type="Comparison")
