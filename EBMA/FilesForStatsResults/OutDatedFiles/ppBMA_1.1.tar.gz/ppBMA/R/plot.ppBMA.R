plot.ppBMA <-
function(obj, type="All", mycol=c("blue", "red", "purple", "green", "orange") ){

  if (type == "All"){
    plot(density(obj[[1]]$BMApred*100,na.rm=T, bw=1),xlab="predicted probability",las=1,ylab="Density",bty="n",lwd=2,col="black",main="BMA Predicted Probabilities", ylim=c(0,.95), xlim=c(-5,105))
     zero<-sum(obj[[1]][,2]==0)
    one<-sum(obj[[1]][,2]==1)
    total<-length(obj[[1]][,2])
    segments(c(-2, 102), c(0,0), c(-2,102), c(zero/total, one/total), lwd=4)
    rug(obj[[1]][,1]*100, col=1)
  }
   
  if(type=="Comparison"){
    plot(NULL ,xlab="predicted probability",las=1,ylab="Density",bty="n",lwd=2,col="black",ylim=c(0,.95),main="Comparing Different Models", xlim=c(-5,105))
    for(i in 3:ncol(obj[[1]])){
lines(density(obj[[1]][,i]*100,na.rm=T, bw=1),lwd=2,col=mycol[(i-2)])
rug(obj[[1]][,i]*100, col=mycol[(i-2)])
}
    legend(60, .55, c("Truth", names(obj[[1]])[3:ncol(obj[[1]])]), text.col=c(1, mycol[1:ncol(obj[[1]])]))
    zero<-sum(obj[[1]][,2]==0)
    one<-sum(obj[[1]][,2]==1)
    total<-length(obj[[1]][,2])
    segments(c(-2, 102), c(0,0), c(-2,102), c(zero/total, one/total), lwd=4) 
  }
}

