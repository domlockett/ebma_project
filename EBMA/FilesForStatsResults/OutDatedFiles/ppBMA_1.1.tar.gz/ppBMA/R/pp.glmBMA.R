# Last edited by Jacob Montgomery on 1/4/2011

# Todo: Make a print() alias for this class
# Todo: Add this into the main package?
# Todo: Should do some beta testing/debugging.  

pp.glmBMA <- function (x, y, prior.param = c(rep(0.5, ncol(x))),
    call = NULL)
{

  create.assign <- function(x) {
        asgn <- list()
        asgn[[1]] <- 1
        cnt <- 2
        for (i in 1:ncol(x)) {
            size <- 1
            asgn[[i + 1]] <- cnt
            cnt <- cnt + size
        }
        names(asgn) <- c("(Intercept)", attributes(x)$names)
        return(asgn)
    }


  
  # This sets up the 'cl' object to be returned in final output
    if (is.null(call))
        cl <- match.call()
    else cl <- call

 
    x <- data.frame(x) # re-storing the matrix of IV's
    names.arg <- names(x) # restoring the names of the variables

    # if no varibale names specified, replacing them with X1, X2, etc.
    if (is.null(names.arg)) {
        names.arg <- paste("X", 1:ncol(x), sep = "")
      }

    # Code for doing listwise deletion for any missingness
        x2 <- na.omit(x)
      used <- match(row.names(x), row.names(x2))
      omitted <- seq(nrow(x))[is.na(used)]
    if (length(omitted) > 0) {
        x <- x2
        y <- y[-omitted]
        warning(paste("There were ", length(omitted), "records deleted due to NA's"))
    }


    # restoring the names of the x-matrix again.  need this?
    output.names <- var.names<- names(x)
   
 
    # Make a list of this weird type that is used below
    glm.assign <- create.assign(x)

    # A 'named' vector of integers that is used below
     fac.levels <- unlist(lapply(glm.assign, length)[-1])
  
    # Re-storing the x matrix.  So can alter it below
    x.df <- data.frame(x = x)

    # Number of total models  
    nmod <- ncol(x) + 1
 
    # making a which matrix with True's along the diagonal
    which <- diag(1, (nmod-1), (nmod-1)) == 1
    which<-rbind(rep((FALSE), ncol(x)), which)

    # the size object to be returned at the end indicating model complexity
    size <- c(0, rep(1, (nmod-1)))

    # probably a cleaner way to do this, but I'm not messing with it.
    # Has to do with the lables object, so i'm not worried
    sep <- ifelse (all(nchar(names.arg) == 1), "", ",")


 # Setting up the bic object that will be in the output
   bic <- label <- rep(0, nmod)

    
    # Setting up the matrix of prior includsion, calculating prior model odds
    prior.mat <- matrix(rep(prior.param, nmod), nmod, ncol(x),
            byrow = TRUE)
        prior <- apply(which * prior.mat + (!which) * (1 - prior.mat),
            1, prod)
        for (k in 1:nmod) {
            if (k == 1)
                label[k] <- "NULL"
            else label[k] <- paste(names.arg[which[k, ]], collapse = sep)
        }

    # actually fitting all of the models and saving relevant information
    model.fits <- as.list(rep(0, nmod))
    dev <- rep(0, nmod)
    df <- rep(0, nmod)
    for (k in 1:nmod) {
        if (sum(which[k, ]) == 0) {
            glm.out <- glm(y ~ 1, family = "binomial")
        }
        else {
            x.df <- data.frame(x = x[, which[k, ]])
            glm.out <- glm(y ~ ., data = x.df, family ="binomial")
        }
        dev[k] <- glm.out$deviance
        df[k] <- glm.out$df.residual
        model.fits[[k]] <- matrix(0, nrow = length(glm.out$coef),
            ncol = 2)
        model.fits[[k]][, 1] <- glm.out$coef
        coef <- glm.out$coef
        p <- glm.out$rank
        R <- glm.out$R
        rinv <- diag(p)
        rinv <- backsolve(R, rinv)
        rowlen <- drop(((rinv^2) %*% rep(1, p))^0.5)
        sigx <- rowlen %o% 1
        correl <- rinv %*% t(rinv) * outer(1/rowlen, 1/rowlen)
        cov <- correl * sigx %*% t(sigx)
        model.fits[[k]][, 2] <- sqrt(diag(cov))
    }

    # Getting the number of observations for bic calculations
    nobs <- length(y)
  
   # bic calculations
    bic <- dev - df * log(nobs) - 2 * log(prior)

    # calculating the posterior model odds    
    postprob <- exp(-0.5 * (bic - min(bic)))/sum(exp(-0.5 * (bic -
        min(bic))))

    # Re-ordering everything by model probability
    order.bic <- order(bic, size, label)
    dev <- dev[order.bic]
    df <- df[order.bic]
    size <- size[order.bic]
    label <- label[order.bic]
    which <- which[order.bic, , drop = FALSE]
    bic <- bic[order.bic]
    prior <- prior[order.bic]
    postprob <- postprob[order.bic]
    model.fits <- model.fits[order.bic]

    # Putting bic back to actual bic/removing prior information
    bic <- bic + 2 * log(prior)

    # probne0 object to be returned
    probne0 <- round(100 * t(which) %*% as.matrix(postprob), 1)
  
    # everything from here to below is calculating conditional and/or posterior
    # means and standard deviations
    nvar <- max(unlist(glm.assign))
    Ebi <- rep(0, nvar)
    SDbi <- rep(0, nvar)
    EbiMk <- matrix(rep(0, nmod * nvar), nrow = nmod)
    sebiMk <- matrix(rep(0, nmod * nvar), nrow = nmod)


   for (i in (1:ncol(x))) {
        whereisit <- glm.assign[[i + 1]]
        if (any(which[, i]))
            for (k in (1:nmod)) if (which[k, i] == TRUE) {
                spot <- sum(which[k, (1:i)])
                posMk <- (c(0, cumsum(fac.levels[which[k, ]])) + 1)[spot]
                posMk <- posMk:(posMk + fac.levels[i] - 1) + 1
                EbiMk[k, whereisit] <- model.fits[[k]][posMk, 1]
                sebiMk[k, whereisit] <- model.fits[[k]][posMk,2]
            }
    }

    for (k in 1:nmod) {
        EbiMk[k, 1] <- model.fits[[k]][1, 1]
        sebiMk[k, 1] <- model.fits[[k]][1, 2]
    }

   Ebi <- postprob %*% EbiMk

   Ebimat <- matrix(rep(Ebi, nmod), nrow = nmod, byrow = TRUE)

   SDbi <- sqrt(postprob %*% (sebiMk^2) + postprob %*% ((EbiMk -
        Ebimat)^2))

    CSDbi <- rep(0, nvar)
    CEbi <- CSDbi
    for (i in (1:ncol(x))) {
        sel <- which[, i]
        if (sum(sel) > 0) {
            cpp <- rbind(postprob[sel]/sum(postprob[sel]))
            CEbi[glm.assign[[i + 1]]] <- as.numeric(cpp %*% EbiMk[sel,
                glm.assign[[i + 1]]])
            CSDbi[glm.assign[[i + 1]]] <- sqrt(cpp %*% (sebiMk[sel,
                glm.assign[[i + 1]]]^2) + cpp %*% ((EbiMk[sel,
                glm.assign[[i + 1]]] - CEbi[glm.assign[[i + 1]]])^2))
        }
    }
    CSDbi[1] <- SDbi[1]
    CEbi[1] <- Ebi[1]



 #  used in final output for reporting prior odds
     prior.weight.denom <- 0.5^ncol(x)

    # assemble the final output
    result<-list(postprob = postprob, label=label, deviance = dev,
                 size=size, bic=bic, prior.param=prior.param,
                 prior.modelweights = prior/prior.weight.denom,
                 which = which, probne = c(probne0),
                 postmean = as.vector(Ebi), postsd = as.vector(SDbi),
                 condpostmean = CEbi, condpostsd = CSDbi, mle = EbiMk,
                 se = sebiMk, namesx = var.names, call = cl,
                 n.models = length(postprob), n.vars = length(probne0))#,
                # x = x, y=y) # When make a print function, put this back
   return(result)
}


