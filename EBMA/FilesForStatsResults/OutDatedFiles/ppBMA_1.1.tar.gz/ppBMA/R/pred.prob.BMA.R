pred.prob.BMA <-
function(y, x, control, training) {

# Read in data, and break it into test and training sets
  x.train<-x[training==1,]
  y.train<-y[training==1]
  x.test<-cbind(1, x[training==0,])
  y.test<-y[training==0]

# Fit the models
 bma.fit<- pp.glmBMA(x.train, y.train)
  
### Now make posterior predictions from each
  eta<-as.matrix(x.test)%*%bma.fit$postmean
  pred<-(exp(eta))/(1+ exp(eta))

 ##Make the dataframe that is going to be output 

  control<-control[training==0,]
  out<-data.frame(pred, y.test, x.test[,-1])
  colnames(out)[1]<-"BMApred"
  colnames(out)[2]<-"Truth"
  out2<-list(out, control)
  names(out2)<-c("Out", "Controls")
  out2
  
}

